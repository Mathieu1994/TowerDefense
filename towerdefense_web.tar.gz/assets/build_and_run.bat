@echo off
echo ===================================================
echo   Alten Build-Ordner loeschen...
echo ===================================================

if exist "build" (
    rmdir /s /q "build"
    echo Alter build-Ordner wurde erfolgreich geloescht.
) else (
    echo Kein alter build-Ordner gefunden.
)

echo.
echo ===================================================
echo   Pygbag starten und neuen Web-Build generieren...
echo ===================================================
python -m pygbag .

pause