import asyncio
import json
import math
import os
import random
import sys
import pygame


# Hilfsfunktion für Assets
def resource_path(relative_path):
  try:
    base_path = sys._MEIPASS
  except Exception:
    base_path = os.path.abspath(".")
  return os.path.join(base_path, relative_path)


# Initialisierung
pygame.init()
DEFAULT_WIDTH, DEFAULT_HEIGHT = 950, 720
screen = pygame.display.set_mode(
    (DEFAULT_WIDTH, DEFAULT_HEIGHT), pygame.RESIZABLE
)
pygame.display.set_caption("Tower Defense")
clock = pygame.time.Clock()

font = pygame.font.SysFont(None, 24)
font_small = pygame.font.SysFont(None, 20)
font_large = pygame.font.SysFont(None, 48)

# Farben
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (80, 80, 80)
LIGHT_GRAY = (220, 220, 220)
YELLOW = (240, 220, 50)
PANEL_BG = (40, 44, 52)
PATH_COLOR = (210, 180, 140)

GRID_SIZE = 40

# --- HIGHSCORE ---
HIGHSCORE_FILE = "highscore.json"


def load_highscore(map_id, difficulty):
  if os.path.exists(HIGHSCORE_FILE):
    try:
      with open(HIGHSCORE_FILE, "r") as f:
        data = json.load(f)
        str_id = str(map_id)
        if str_id in data and difficulty in data[str_id]:
          return data[str_id][difficulty]
        elif str_id in data and "wave" in data[str_id]:
          return data[str_id]
        elif "wave" in data and map_id == 1:
          return data
    except:
      pass
  return {"wave": 0}


def save_highscore(map_id, difficulty, wave):
  all_hs = {}
  if os.path.exists(HIGHSCORE_FILE):
    try:
      with open(HIGHSCORE_FILE, "r") as f:
        all_hs = json.load(f)
    except:
      pass

  str_id = str(map_id)
  if str_id not in all_hs or not isinstance(all_hs[str_id], dict):
    all_hs[str_id] = {}

  current_diff_hs = all_hs[str_id].get(difficulty, {"wave": 0})

  if wave > current_diff_hs.get("wave", 0):
    data = {"wave": wave}
    all_hs[str_id][difficulty] = data
    try:
      with open(HIGHSCORE_FILE, "w") as f:
        json.dump(all_hs, f)
    except:
      pass
    return data
  return current_diff_hs


# --- ASSET-MANAGER ---
class AssetManager:

  def __init__(self):
    self.sheets = {}
    self.tower_images = {}
    self.map_thumbs = {}
    self.bg_home = None
    self.bg_tile = None
    self.bg_path = None
    self.bg_portal = None
    self.bg_castle = None
    self.load_assets()

  def load_assets(self):
    assets_dir = resource_path("assets")
    if not os.path.exists(assets_dir):
      return

    h_path = os.path.join(assets_dir, "home.png")
    if os.path.exists(h_path):
      try:
        self.bg_home = pygame.image.load(h_path).convert()
      except:
        pass

    t_path = os.path.join(assets_dir, "tile1.png")
    if os.path.exists(t_path):
      try:
        self.bg_tile = pygame.image.load(t_path).convert()
      except:
        pass

    dp_path = os.path.join(assets_dir, "dirt_path.png")
    if os.path.exists(dp_path):
      try:
        self.bg_path = pygame.image.load(dp_path).convert_alpha()
      except:
        pass

    p_path = os.path.join(assets_dir, "portal.png")
    if os.path.exists(p_path):
      try:
        self.bg_portal = pygame.image.load(p_path).convert_alpha()
      except:
        pass

    c_path = os.path.join(assets_dir, "castle.png")
    if os.path.exists(c_path):
      try:
        self.bg_castle = pygame.image.load(c_path).convert_alpha()
      except:
        pass

    for m_id in range(1, 7):
      m_path = os.path.join(assets_dir, f"map{m_id}.png")
      if os.path.exists(m_path):
        try:
          self.map_thumbs[m_id] = pygame.image.load(m_path).convert_alpha()
        except:
          pass

    enemy_files = {
        "zombie": "zombie.png",
        "creeper": "creeper.png",
        "spider": "spider.png",
        "iron_golem": "iron_golem.png",
        "baby_zombie": "baby_zombie.png",
        "gast": "gast.png",
        "piglin": "piglin.png",
        "enderman": "enderman.png",
    }
    for name, filename in enemy_files.items():
      path = os.path.join(assets_dir, filename)
      if os.path.exists(path):
        try:
          sheet_img = pygame.image.load(path).convert_alpha()
          self.sheets[name] = self.parse_sheet(sheet_img)
        except:
          pass

    tower_files = {
        "standard": "standard.png",
        "sniper": "sniper.png",
        "rapid": "rapid.png",
    }
    for name, filename in tower_files.items():
      path = os.path.join(assets_dir, filename)
      if os.path.exists(path):
        try:
          self.tower_images[name] = pygame.image.load(path).convert_alpha()
        except:
          pass

  def parse_sheet(self, sheet_img):
    sheet_w, sheet_h = sheet_img.get_size()
    cols, rows = 12, 4
    frame_w, frame_h = sheet_w // cols, sheet_h // rows
    frames = {"right": [], "left": [], "up": [], "down": []}
    directions = ["right", "left", "up", "down"]
    for r in range(rows):
      dir_name = directions[r]
      for c in range(cols):
        rect = pygame.Rect(c * frame_w, r * frame_h, frame_w, frame_h)
        frame = pygame.Surface((frame_w, frame_h), pygame.SRCALPHA)
        frame.blit(sheet_img, (0, 0), rect)
        frames[dir_name].append(frame)
    return frames


assets = AssetManager()

MAPS = {
    1: {
        "name": "Die Grüne Ebene",
        "waypoints": [(1, 2), (21, 2), (21, 8), (3, 8), (3, 12), (22, 12)],
    },
    2: {
        "name": "Der Schlangenpfad",
        "waypoints": [(2, 6), (10, 6), (10, 2), (18, 2), (18, 10), (6, 10)],
    },
    3: {
        "name": "Nether Schlucht",
        "waypoints": [(1, 1), (22, 1), (22, 12), (1, 12)],
    },
    4: {
        "name": "Das Labyrinth",
        "waypoints": [
            (2, 2),
            (20, 2),
            (20, 5),
            (5, 5),
            (5, 9),
            (21, 9),
            (21, 12),
        ],
    },
    5: {
        "name": "Zickzack-Hölle",
        "waypoints": [
            (1, 6),
            (6, 2),
            (11, 10),
            (16, 2),
            (21, 10),
            (22, 6),
        ],
    },
    6: {
        "name": "Die End-Insel",
        "waypoints": [
            (12, 1),
            (12, 12),
            (2, 12),
            (2, 6),
            (22, 6),
            (22, 1),
        ],
    },
}

selected_map_id = 1


def load_map_path(map_id):
  waypoints_grid = MAPS[map_id]["waypoints"]
  cells = set()
  for i in range(len(waypoints_grid) - 1):
    x0, y0 = waypoints_grid[i]
    x1, y1 = waypoints_grid[i + 1]
    dx, dy = abs(x1 - x0), abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy
    cx, cy = x0, y0
    while True:
      cells.add((cx, cy))
      if cx == x1 and cy == y1:
        break
      e2 = 2 * err
      if e2 > -dy:
        err -= dy
        cx += sx
      if e2 < dx:
        err += dx
        cy += sy
  pixels = [
      (gx * GRID_SIZE + GRID_SIZE // 2, gy * GRID_SIZE + GRID_SIZE // 2)
      for gx, gy in waypoints_grid
  ]
  return cells, waypoints_grid, pixels


PATH_CELLS, WAYPOINTS_GRID, path_pixels = load_map_path(selected_map_id)
START_CELL = WAYPOINTS_GRID[0]
END_CELL = WAYPOINTS_GRID[-1]

ENEMY_TYPES = {
    "baby_zombie": {
        "speed": 4.2,
        "health": 50,
        "color": (100, 150, 100),
        "reward": 8,
        "size": 16,
        "sprite": "baby_zombie",
    },
    "spider": {
        "speed": 3.6,
        "health": 75,
        "color": (50, 50, 50),
        "reward": 10,
        "size": 18,
        "sprite": "spider",
    },
    "zombie": {
        "speed": 2.2,
        "health": 120,
        "color": (46, 204, 113),
        "reward": 12,
        "size": 20,
        "sprite": "zombie",
    },
    "creeper": {
        "speed": 2.5,
        "health": 100,
        "color": (0, 200, 0),
        "reward": 15,
        "size": 20,
        "sprite": "creeper",
    },
    "piglin": {
        "speed": 2.0,
        "health": 180,
        "color": (210, 105, 30),
        "reward": 18,
        "size": 20,
        "sprite": "piglin",
    },
    "enderman": {
        "speed": 2.8,
        "health": 220,
        "color": (30, 30, 30),
        "reward": 22,
        "size": 22,
        "sprite": "enderman",
    },
    "iron_golem": {
        "speed": 1.2,
        "health": 450,
        "color": (220, 220, 220),
        "reward": 35,
        "size": 26,
        "sprite": "iron_golem",
    },
    "gast": {
        "speed": 1.4,
        "health": 850,
        "color": (240, 240, 240),
        "reward": 75,
        "size": 30,
        "sprite": "gast",
    },
}

TOWER_TYPES = {
    "standard": {
        "name": "Standard",
        "cost": 100,
        "range": 130,
        "cooldown": 25,
        "damage": 35,
        "color": (41, 128, 185),
        "proj_speed": 9.0,
    },
    "sniper": {
        "name": "Scharfschütze",
        "cost": 180,
        "range": 240,
        "cooldown": 65,
        "damage": 135,
        "color": (24, 44, 97),
        "proj_speed": 18.0,
    },
    "rapid": {
        "name": "Schnellfeuer",
        "cost": 230,
        "range": 110,
        "cooldown": 7,
        "damage": 14,
        "color": (26, 188, 156),
        "proj_speed": 12.0,
    },
}


class Enemy:

  def __init__(self, enemy_type, wave_number, difficulty):
    self.type_name = enemy_type
    stats = ENEMY_TYPES[enemy_type]
    self.x, self.y = path_pixels[0]
    self.path_index = 0
    self.speed = stats["speed"]
    self.sprite_key = stats["sprite"]
    diff_scaling = {"easy": 0.30, "medium": 0.45, "hard": 0.65}[difficulty]
    scale_factor = 1.0 + (wave_number - 1) * diff_scaling
    self.max_health = int(stats["health"] * scale_factor)
    self.health = self.max_health
    self.color = stats["color"]
    self.reward = stats["reward"]
    self.size = stats["size"]
    self.anim_frame = 0
    self.direction = "right"

  def update(self, speed_multiplier):
    eff_speed = self.speed * speed_multiplier
    if self.path_index < len(path_pixels) - 1:
      target_x, target_y = path_pixels[self.path_index + 1]
      dx, dy = target_x - self.x, target_y - self.y
      dist = math.hypot(dx, dy)
      if abs(dx) > abs(dy):
        self.direction = "right" if dx > 0 else "left"
      else:
        self.direction = "down" if dy > 0 else "up"
      if dist < eff_speed:
        self.path_index += 1
      else:
        self.x += (dx / dist) * eff_speed
        self.y += (dy / dist) * eff_speed
      self.anim_frame = (self.anim_frame + 0.2 * speed_multiplier) % 12
      return False
    else:
      return True

  def draw(self, surface):
    drawn = False
    if self.sprite_key in assets.sheets:
      frames = assets.sheets[self.sprite_key][self.direction]
      if frames:
        current_frame = frames[int(self.anim_frame)]
        scaled_frame = pygame.transform.scale(
            current_frame, (self.size * 2, self.size * 2)
        )
        rect = scaled_frame.get_rect(center=(int(self.x), int(self.y)))
        surface.blit(scaled_frame, rect)
        drawn = True
    if not drawn:
      pygame.draw.circle(
          surface, self.color, (int(self.x), int(self.y)), self.size
      )

    bar_width = max(24, self.size * 2)
    fill = max(0, (self.health / self.max_health) * bar_width)
    pygame.draw.rect(
        surface,
        (200, 50, 50),
        (int(self.x) - bar_width / 2, int(self.y) - self.size - 9, bar_width, 4),
    )
    pygame.draw.rect(
        surface,
        (46, 204, 113),
        (int(self.x) - bar_width / 2, int(self.y) - self.size - 9, fill, 4),
    )


class Projectile:

  def __init__(self, x, y, target_enemy, tower_type, damage):
    self.x, self.y = x, y
    self.target = target_enemy
    self.tower_type = tower_type
    self.damage = damage
    self.speed = TOWER_TYPES[tower_type]["proj_speed"]
    self.alive = True

  def update(self, speed_multiplier):
    if not self.target or self.target.health <= 0:
      self.alive = False
      return
    dx, dy = self.target.x - self.x, self.target.y - self.y
    dist = math.hypot(dx, dy)
    move_dist = self.speed * speed_multiplier
    if dist <= move_dist:
      self.target.health -= self.damage
      self.alive = False
    else:
      self.x += (dx / dist) * move_dist
      self.y += (dy / dist) * move_dist

  def draw(self, surface):
    if self.tower_type == "standard":
      pygame.draw.circle(
          surface, (241, 196, 15), (int(self.x), int(self.y)), 5
      )
    elif self.tower_type == "sniper":
      dx, dy = self.target.x - self.x, self.target.y - self.y
      dist = max(1, math.hypot(dx, dy))
      pygame.draw.line(
          surface,
          (231, 76, 60),
          (self.x, self.y),
          (self.x - (dx / dist) * 14, self.y - (dy / dist) * 14),
          3,
      )
    elif self.tower_type == "rapid":
      pygame.draw.circle(surface, (52, 231, 228), (int(self.x), int(self.y)), 3)


class Tower:

  def __init__(self, grid_x, grid_y, tower_type):
    self.grid_x, self.grid_y = grid_x, grid_y
    self.x = grid_x * GRID_SIZE + GRID_SIZE // 2
    self.y = grid_y * GRID_SIZE + GRID_SIZE // 2
    stats = TOWER_TYPES[tower_type]
    self.type_key = tower_type
    self.range = stats["range"]
    self.max_cooldown = stats["cooldown"]
    self.cooldown = 0
    self.damage = stats["damage"]
    self.color = stats["color"]

  def update(self, enemies, speed_multiplier, projectiles):
    if self.cooldown > 0:
      self.cooldown -= speed_multiplier
    if self.cooldown <= 0:
      for enemy in enemies:
        if math.hypot(enemy.x - self.x, enemy.y - self.y) <= self.range:
          projectiles.append(
              Projectile(
                  self.x, self.y, enemy, self.type_key, self.damage
              )
          )
          self.cooldown = self.max_cooldown
          break

  def draw(self, surface):
    if self.type_key in assets.tower_images:
      img = assets.tower_images[self.type_key]
      scaled = pygame.transform.scale(img, (GRID_SIZE - 4, GRID_SIZE - 4))
      surface.blit(scaled, scaled.get_rect(center=(self.x, self.y)))
    else:
      pygame.draw.rect(
          surface,
          self.color,
          (
              self.grid_x * GRID_SIZE + 2,
              self.grid_y * GRID_SIZE + 2,
              GRID_SIZE - 4,
              GRID_SIZE - 4,
          ),
      )

  def draw_range(self, surface):
    rs = pygame.Surface((self.range * 2, self.range * 2), pygame.SRCALPHA)
    pygame.draw.circle(
        rs, (50, 150, 250, 40), (self.range, self.range), self.range
    )
    pygame.draw.circle(
        rs, (50, 150, 250, 200), (self.range, self.range), self.range, 2
    )
    surface.blit(rs, (self.x - self.range, self.y - self.range))


game_state = "MENU"
selected_difficulty = "medium"
towers, enemies, projectiles = [], [], []
gold, lives, wave, wave_queue, spawn_timer = 250, 12, 0, [], 0
game_over = False
selected_tower_type = None
selected_placed_tower = None
game_speed = 1


def start_new_game(difficulty):
  global towers, enemies, projectiles, gold, lives, wave, wave_queue, spawn_timer, game_over, selected_tower_type, selected_placed_tower, game_speed
  towers, enemies, projectiles = [], [], []
  gold = {"easy": 320, "medium": 230, "hard": 160}[difficulty]
  lives = {"easy": 15, "medium": 10, "hard": 5}[difficulty]
  wave, wave_queue, spawn_timer, game_over = 0, [], 0, False
  selected_tower_type, selected_placed_tower, game_speed = None, None, 1
  start_next_wave(difficulty)


def generate_wave(wave_num, difficulty):
  count = int(
      6
      + wave_num
      * {"easy": 3.5, "medium": 4.8, "hard": 6.5}[difficulty]
  )
  pool = ["baby_zombie", "zombie"]
  if wave_num >= 2:
    pool.append("creeper")
  if wave_num >= 3:
    pool.extend(["spider", "piglin"])
  if wave_num >= 5:
    pool.append("enderman")
  if wave_num >= 7:
    pool.append("iron_golem")
  if wave_num >= 9:
    pool.append("gast")
  queue = [random.choice(pool) for _ in range(count)]
  if wave_num % 3 == 0:
    queue.append(
        "gast"
        if wave_num >= 9
        else ("iron_golem" if wave_num >= 6 else "enderman")
    )
  return queue


def start_next_wave(difficulty):
  global wave, wave_queue, spawn_timer
  wave += 1
  wave_queue = generate_wave(wave, difficulty)
  spawn_timer = 0


async def main():
  global running, game_state, selected_difficulty, towers, enemies, projectiles
  global gold, lives, wave, wave_queue, spawn_timer, game_over
  global selected_tower_type, selected_placed_tower, game_speed
  global selected_map_id, PATH_CELLS, WAYPOINTS_GRID, path_pixels, START_CELL, END_CELL

  running = True
  while running:
    win_w, win_h = screen.get_size()
    is_portrait = win_h > win_w

    virt_w, virt_h = (720, 980) if is_portrait else (950, 720)
    PLAY_HEIGHT = 620 if not is_portrait else 700

    # UI-Layout-Definitionen je nach Ausrichtung
    if is_portrait:
      map_buttons = {}
      for i in range(1, 7):
        col, row = (i - 1) % 3, (i - 1) // 3
        map_buttons[i] = pygame.Rect(
            60 + col * 200, 420 + row * 82, 180, 70
        )
      menu_diff_buttons = {
          "easy": pygame.Rect(210, 620, 90, 40),
          "medium": pygame.Rect(315, 620, 90, 40),
          "hard": pygame.Rect(420, 620, 90, 40),
      }
      play_button_rect = pygame.Rect(260, 675, 200, 50)
      menu_buttons = [
          {"type": "standard", "rect": pygame.Rect(60, 735, 180, 70)},
          {"type": "sniper", "rect": pygame.Rect(270, 735, 180, 70)},
          {"type": "rapid", "rect": pygame.Rect(480, 735, 180, 70)},
      ]
      speed_buttons = [
          {"speed": 1, "rect": pygame.Rect(540, 10, 35, 30)},
          {"speed": 2, "rect": pygame.Rect(580, 10, 35, 30)},
          {"speed": 4, "rect": pygame.Rect(620, 10, 35, 30)},
          {"speed": 8, "rect": pygame.Rect(660, 10, 35, 30)},
      ]
    else:
      map_buttons = {}
      for i in range(1, 7):
        col, row = (i - 1) % 3, (i - 1) // 3
        map_buttons[i] = pygame.Rect(
            175 + col * 200, 300 + row * 82, 180, 70
        )
      menu_diff_buttons = {
          "easy": pygame.Rect(325, 500, 90, 40),
          "medium": pygame.Rect(430, 500, 90, 40),
          "hard": pygame.Rect(535, 500, 90, 40),
      }
      play_button_rect = pygame.Rect(375, 545, 200, 50)
      menu_buttons = [
          {"type": "standard", "rect": pygame.Rect(180, 650, 160, 70)},
          {"type": "sniper", "rect": pygame.Rect(350, 650, 160, 70)},
          {"type": "rapid", "rect": pygame.Rect(520, 650, 160, 70)},
      ]
      speed_buttons = [
          {"speed": 1, "rect": pygame.Rect(770, 10, 35, 30)},
          {"speed": 2, "rect": pygame.Rect(810, 10, 35, 30)},
          {"speed": 4, "rect": pygame.Rect(850, 10, 35, 30)},
          {"speed": 8, "rect": pygame.Rect(890, 10, 35, 30)},
      ]

    # Events verarbeiten
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False
      elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        real_mx, real_my = event.pos
        mx = int(real_mx / (win_w / virt_w))
        my = int(real_my / (win_h / virt_h))

        if game_state == "MENU":
          for diff, rect in menu_diff_buttons.items():
            if rect.collidepoint(mx, my):
              selected_difficulty = diff
          for m_id, rect in map_buttons.items():
            if rect.collidepoint(mx, my):
              selected_map_id = m_id
              PATH_CELLS, WAYPOINTS_GRID, path_pixels = load_map_path(
                  selected_map_id
              )
              START_CELL, END_CELL = WAYPOINTS_GRID[0], WAYPOINTS_GRID[-1]
          if play_button_rect.collidepoint(mx, my):
            start_new_game(selected_difficulty)
            game_state = "PLAYING"

        elif game_state == "PLAYING":
          clicked_speed = False
          for sb in speed_buttons:
            if sb["rect"].collidepoint(mx, my):
              game_speed = sb["speed"]
              clicked_speed = True
              break
          if not clicked_speed:
            if game_over:
              back_rect = pygame.Rect(
                  virt_w // 2 - 110, PLAY_HEIGHT // 2 + 50, 220, 40
              )
              if back_rect.collidepoint(mx, my):
                game_state, game_over = "MENU", False
            else:
              if my >= PLAY_HEIGHT:
                clicked_button = False
                for b in menu_buttons:
                  if b["rect"].collidepoint(mx, my):
                    clicked_button = True
                    if selected_tower_type == b["type"]:
                      selected_tower_type = None
                    else:
                      selected_tower_type = b["type"]
                      selected_placed_tower = None
                    break
                if not clicked_button:
                  selected_tower_type = None
              else:
                gx, gy = mx // GRID_SIZE, my // GRID_SIZE
                clicked_tower = next(
                    (t for t in towers if t.grid_x == gx and t.grid_y == gy),
                    None,
                )
                if selected_tower_type is not None:
                  cost = TOWER_TYPES[selected_tower_type]["cost"]
                  if (
                      clicked_tower is None
                      and (gx, gy) not in PATH_CELLS
                      and gold >= cost
                  ):
                    towers.append(Tower(gx, gy, selected_tower_type))
                    gold -= cost
                else:
                  selected_placed_tower = clicked_tower

    real_mx, real_my = pygame.mouse.get_pos()
    mx = int(real_mx / (win_w / virt_w))
    my = int(real_my / (win_h / virt_h))

    if game_state == "PLAYING" and not game_over:
      if wave_queue:
        spawn_timer += game_speed
        if spawn_timer >= 30:
          enemies.append(Enemy(wave_queue.pop(0), wave, selected_difficulty))
          spawn_timer = 0
      elif not enemies and not projectiles:
        start_next_wave(selected_difficulty)

      for enemy in enemies[:]:
        if enemy.update(game_speed):
          enemies.remove(enemy)
          lives -= 1
          if lives <= 0:
            game_over = True
            save_highscore(selected_map_id, selected_difficulty, wave)
        elif enemy.health <= 0:
          gold += enemy.reward
          enemies.remove(enemy)

      for tower in towers:
        tower.update(enemies, game_speed, projectiles)
      for proj in projectiles[:]:
        proj.update(game_speed)
        if not proj.alive:
          projectiles.remove(proj)

    # Direkt auf den echten screen zeichnen für maximale Schärfe
    screen.fill(WHITE)

    # Render-Surface erstellen mit echter nativer Skalierung für das Layout
    render_surf = pygame.Surface((virt_w, virt_h))
    render_surf.fill(WHITE)

    if game_state == "PLAYING":
      if assets.bg_tile:
        tw, th = assets.bg_tile.get_size()
        for ty in range(0, PLAY_HEIGHT, th):
          for tx in range(0, virt_w, tw):
            render_surf.blit(assets.bg_tile, (tx, ty))
      else:
        for x in range(0, virt_w, GRID_SIZE):
          pygame.draw.line(render_surf, (240, 240, 240), (x, 0), (x, PLAY_HEIGHT), 1)
        for y in range(0, PLAY_HEIGHT, GRID_SIZE):
          pygame.draw.line(render_surf, (240, 240, 240), (0, y), (virt_w, y), 1)

      for gx, gy in PATH_CELLS:
        if (gx, gy) == START_CELL and assets.bg_portal:
          render_surf.blit(
              pygame.transform.scale(assets.bg_portal, (GRID_SIZE, GRID_SIZE)),
              (gx * GRID_SIZE, gy * GRID_SIZE),
          )
        elif (gx, gy) == END_CELL and assets.bg_castle:
          render_surf.blit(
              pygame.transform.scale(assets.bg_castle, (GRID_SIZE, GRID_SIZE)),
              (gx * GRID_SIZE, gy * GRID_SIZE),
          )
        else:
          if assets.bg_path:
            render_surf.blit(
                pygame.transform.scale(assets.bg_path, (GRID_SIZE, GRID_SIZE)),
                (gx * GRID_SIZE, gy * GRID_SIZE),
            )
          else:
            pygame.draw.rect(
                render_surf,
                PATH_COLOR,
                (gx * GRID_SIZE, gy * GRID_SIZE, GRID_SIZE, GRID_SIZE),
            )

      for tower in towers:
        tower.draw(render_surf)
      if selected_placed_tower and selected_tower_type is None:
        selected_placed_tower.draw_range(render_surf)
      for proj in projectiles:
        proj.draw(render_surf)
      for enemy in enemies:
        enemy.draw(render_surf)

      if selected_tower_type and my < PLAY_HEIGHT:
        gx, gy = mx // GRID_SIZE, my // GRID_SIZE
        cx, cy = gx * GRID_SIZE + GRID_SIZE // 2, gy * GRID_SIZE + GRID_SIZE // 2
        stats = TOWER_TYPES[selected_tower_type]
        on_path = (gx, gy) in PATH_CELLS
        pc = (231, 76, 60) if on_path else (50, 150, 250)
        ps = pygame.Surface(
            (stats["range"] * 2, stats["range"] * 2), pygame.SRCALPHA
        )
        pygame.draw.circle(
            ps, (*pc[:3], 40), (stats["range"], stats["range"]), stats["range"]
        )
        pygame.draw.circle(
            ps,
            (*pc[:3], 200),
            (stats["range"], stats["range"]),
            stats["range"],
            1,
        )
        render_surf.blit(ps, (cx - stats["range"], cy - stats["range"]))
        if selected_tower_type in assets.tower_images:
          ti = assets.tower_images[selected_tower_type]
          render_surf.blit(
              pygame.transform.scale(ti, (GRID_SIZE - 4, GRID_SIZE - 4)),
              pygame.transform.scale(
                  ti, (GRID_SIZE - 4, GRID_SIZE - 4)
              ).get_rect(center=(cx, cy)),
          )

      # UI Stats oben
      render_surf.blit(
          font.render(
              f"Gold: {gold} | Leben: {lives} | Welle: {wave}", True, BLACK
          ),
          (15, 12),
      )
      for sb in speed_buttons:
        c = YELLOW if game_speed == sb["speed"] else LIGHT_GRAY
        pygame.draw.rect(render_surf, c, sb["rect"], border_radius=4)
        pygame.draw.rect(
            render_surf, DARK_GRAY, sb["rect"], width=1, border_radius=4
        )
        render_surf.blit(
            font_small.render(f"x{sb['speed']}", True, BLACK),
            (sb["rect"].x + 8, sb["rect"].y + 7),
        )

      # Unteres Panel
      pygame.draw.rect(
          render_surf,
          PANEL_BG,
          (0, PLAY_HEIGHT, virt_w, virt_h - PLAY_HEIGHT),
      )
      active_type_key = selected_tower_type or (
          selected_placed_tower.type_key if selected_placed_tower else None
      )

      if is_portrait:
        render_surf.blit(font.render("Auswahl:", True, WHITE), (20, PLAY_HEIGHT + 15))
        if active_type_key:
          render_surf.blit(
              font.render(
                  f"{TOWER_TYPES[active_type_key]['name']}", True, YELLOW
              ),
              (110, PLAY_HEIGHT + 15),
          )
          render_surf.blit(
              font_small.render(
                  (
                      "(Bauen aktiv)"
                      if selected_tower_type
                      else "(Platziert)"
                  ),
                  True,
                  LIGHT_GRAY,
              ),
              (260, PLAY_HEIGHT + 17),
          )
        else:
          render_surf.blit(
              font_small.render("Kein Turm gewählt", True, GRAY),
              (110, PLAY_HEIGHT + 17),
          )

        for b in menu_buttons:
          t_data = TOWER_TYPES[b["type"]]
          pygame.draw.rect(
              render_surf,
              YELLOW if selected_tower_type == b["type"] else LIGHT_GRAY,
              b["rect"],
              border_radius=6,
          )
          if b["type"] in assets.tower_images:
            render_surf.blit(
                pygame.transform.scale(assets.tower_images[b["type"]], (36, 36)),
                (b["rect"].x + 8, b["rect"].y + 17),
            )
          render_surf.blit(
              font.render(t_data["name"], True, BLACK),
              (b["rect"].x + 48, b["rect"].y + 15),
          )
          render_surf.blit(
              font.render(f"{t_data['cost']} Gold", True, DARK_GRAY),
              (b["rect"].x + 48, b["rect"].y + 38),
          )

        render_surf.blit(
            font.render("Charakteristiken:", True, WHITE), (20, 830)
        )
        if active_type_key:
          t_info = TOWER_TYPES[active_type_key]
          aps = round(60 / t_info["cooldown"], 1)
          render_surf.blit(
              font_small.render(
                  f"Schaden: {t_info['damage']} | Reichweite: {t_info['range']} | Schussrate: {aps}/s",
                  True,
                  WHITE,
              ),
              (20, 860),
          )
        else:
          render_surf.blit(
              font_small.render("Turm wählen für Details", True, GRAY),
              (20, 860),
          )
      else:
        render_surf.blit(font.render("Auswahl:", True, WHITE), (15, PLAY_HEIGHT + 15))
        if active_type_key:
          render_surf.blit(
              font.render(
                  f"{TOWER_TYPES[active_type_key]['name']}", True, YELLOW
              ),
              (15, PLAY_HEIGHT + 35),
          )
          render_surf.blit(
              font_small.render(
                  (
                      "(Bauen aktiv)"
                      if selected_tower_type
                      else "(Platziert)"
                  ),
                  True,
                  LIGHT_GRAY,
              ),
              (15, PLAY_HEIGHT + 55),
          )
        else:
          render_surf.blit(
              font_small.render("Kein Turm gewählt", True, GRAY),
              (15, PLAY_HEIGHT + 40),
          )

        for b in menu_buttons:
          t_data = TOWER_TYPES[b["type"]]
          pygame.draw.rect(
              render_surf,
              YELLOW if selected_tower_type == b["type"] else LIGHT_GRAY,
              b["rect"],
              border_radius=6,
          )
          if b["type"] in assets.tower_images:
            render_surf.blit(
                pygame.transform.scale(assets.tower_images[b["type"]], (36, 36)),
                (b["rect"].x + 8, b["rect"].y + 17),
            )
          render_surf.blit(
              font.render(t_data["name"], True, BLACK),
              (b["rect"].x + 50, b["rect"].y + 15),
          )
          render_surf.blit(
              font.render(f"{t_data['cost']} Gold", True, DARK_GRAY),
              (b["rect"].x + 50, b["rect"].y + 38),
          )

        pygame.draw.line(
            render_surf, DARK_GRAY, (715, PLAY_HEIGHT + 10), (715, virt_h - 10), 1
        )
        render_surf.blit(
            font.render("Charakteristiken:", True, WHITE), (730, PLAY_HEIGHT + 10)
        )
        if active_type_key:
          t_info = TOWER_TYPES[active_type_key]
          aps = round(60 / t_info["cooldown"], 1)
          render_surf.blit(
              font_small.render(
                  f"Schaden: {t_info['damage']}", True, WHITE
              ),
              (730, PLAY_HEIGHT + 32),
          )
          render_surf.blit(
              font_small.render(
                  f"Reichweite: {t_info['range']}", True, WHITE
              ),
              (730, PLAY_HEIGHT + 48),
          )
          render_surf.blit(
              font_small.render(
                  f"Schussrate: {aps} /s", True, WHITE
              ),
              (730, PLAY_HEIGHT + 64),
          )
        else:
          render_surf.blit(
              font_small.render("Turm wählen für Details", True, GRAY),
              (730, PLAY_HEIGHT + 40),
          )

      if game_over:
        gb = pygame.Surface((virt_w, PLAY_HEIGHT))
        gb.set_alpha(200)
        gb.fill((0, 0, 0))
        render_surf.blit(gb, (0, 0))
        render_surf.blit(
            font_large.render("GAME OVER", True, (231, 76, 60)),
            (virt_w // 2 - 100, PLAY_HEIGHT // 2 - 40),
        )
        render_surf.blit(
            font.render(f"Du hast Welle {wave} erreicht!", True, WHITE),
            (virt_w // 2 - 95, PLAY_HEIGHT // 2 + 10),
        )
        br = pygame.Rect(virt_w // 2 - 110, PLAY_HEIGHT // 2 + 50, 220, 40)
        pygame.draw.rect(render_surf, YELLOW, br, border_radius=6)
        render_surf.blit(
            font.render("Zurück zum Menü", True, BLACK),
            (br.x + 30, br.y + 10),
        )

    elif game_state == "MENU":
      if assets.bg_home:
        if is_portrait:
          orig_w, orig_h = assets.bg_home.get_size()
          cm = int(orig_w * (1.0 / 6.0))
          cr = pygame.Rect(cm, 0, orig_w - 2 * cm, orig_h)
          ch = pygame.Surface(cr.size)
          ch.blit(assets.bg_home, (0, 0), cr)
          render_surf.blit(
              pygame.transform.scale(ch, (virt_w, virt_h)), (0, 0)
          )
        else:
          render_surf.blit(
              pygame.transform.scale(assets.bg_home, (virt_w, virt_h)), (0, 0)
          )
      else:
        render_surf.fill(PANEL_BG)

      hs = load_highscore(selected_map_id, selected_difficulty)
      mn = MAPS[selected_map_id]["name"]
      hs_surf = font.render(
          f"Highscore [{mn} - {selected_difficulty.capitalize()}]: Welle {hs['wave']}",
          True,
          YELLOW,
      )
      bw, bh = hs_surf.get_width() + 20, hs_surf.get_height() + 20
      bx, by = virt_w // 2 - bw // 2, 580 if is_portrait else 460
      bs = pygame.Surface((bw, bh), pygame.SRCALPHA)
      bs.fill((30, 30, 30, 200))
      render_surf.blit(bs, (bx, by))
      render_surf.blit(hs_surf, (bx + 10, by + 10))

      for m_id, rect in map_buttons.items():
        bsurf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        bsurf.fill((40, 44, 52, 220))
        render_surf.blit(bsurf, (rect.x, rect.y))
        if m_id in assets.map_thumbs:
          render_surf.blit(
              pygame.transform.scale(
                  assets.map_thumbs[m_id], (rect.width - 10, rect.height - 28)
              ),
              (rect.x + 5, rect.y + 5),
          )
        pygame.draw.rect(
            render_surf,
            YELLOW if selected_map_id == m_id else DARK_GRAY,
            rect,
            width=3,
            border_radius=6,
        )
        lbl = font_small.render(MAPS[m_id]["name"], True, WHITE)
        render_surf.blit(
            lbl,
            (
                rect.x + (rect.width - lbl.get_width()) // 2,
                rect.y + rect.height - 22,
            ),
        )

      for diff, rect in menu_diff_buttons.items():
        pygame.draw.rect(
            render_surf,
            YELLOW if selected_difficulty == diff else LIGHT_GRAY,
            rect,
            border_radius=6,
        )
        txt = font.render(diff.capitalize(), True, BLACK)
        render_surf.blit(
            txt,
            (
                rect.x + (rect.width - txt.get_width()) // 2,
                rect.y + 10,
            ),
        )

      pygame.draw.rect(
          render_surf, (46, 204, 113), play_button_rect, border_radius=8
      )
      ptxt = font_large.render("PLAY", True, WHITE)
      render_surf.blit(
          ptxt,
          (
              play_button_rect.x
              + (play_button_rect.width - ptxt.get_width()) // 2,
              play_button_rect.y + 5,
          ),
      )

    # 1x sauberes Skalieren auf den echten Schirm (Knackenscharf!)
    screen.blit(
        pygame.transform.smoothscale(render_surf, (win_w, win_h)), (0, 0)
    )
    pygame.display.flip()
    clock.tick(60)
    await asyncio.sleep(0)

  pygame.quit()
  sys.exit()


asyncio.run(main())