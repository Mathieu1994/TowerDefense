import json
import math
import os
import random
import sys
import pygame
import asyncio


# Hilfsfunktion, damit Assets sowohl als Skript als auch in der PyInstaller-EXE gefunden werden
def resource_path(relative_path):
  try:
    base_path = sys._MEIPASS
  except Exception:
    base_path = os.path.abspath(".")
  return os.path.join(base_path, relative_path)


# Initialisierung
pygame.init()
WIDTH, HEIGHT = 414, 736
PLAY_HEIGHT = 552  # Spielfeldhöhe (3/4, unterer Bereich genau 1/4 = 184px)
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tower Defense - Single-File EXE")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 22)
font_small = pygame.font.SysFont(None, 18)
font_large = pygame.font.SysFont(None, 36)

# Farben
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (80, 80, 80)
LIGHT_GRAY = (220, 220, 220)
YELLOW = (240, 220, 50)
PANEL_BG = (40, 44, 52)
PATH_COLOR = (210, 180, 140)

# Raster-Größe & Dimensionen
GRID_SIZE = 40
COLS = WIDTH // GRID_SIZE
ROWS = PLAY_HEIGHT // GRID_SIZE

# --- HIGHSCORE LADEN / SPEICHERN ---
HIGHSCORE_FILE = "highscore.json"


def load_highscore(map_id, difficulty):
  if os.path.exists(HIGHSCORE_FILE):
    try:
      with open(HIGHSCORE_FILE, "r") as f:
        data = json.load(f)
        str_id = str(map_id)
        if str_id in data and difficulty in data[str_id]:
          return data[str_id][difficulty]
        elif str_id in data and "wave" in data[str_id]:
          return data[str_id]
        elif "wave" in data and map_id == 1:
          return data
    except:
      pass
  return {"wave": 0}


def save_highscore(map_id, difficulty, wave):
  all_hs = {}
  if os.path.exists(HIGHSCORE_FILE):
    try:
      with open(HIGHSCORE_FILE, "r") as f:
        all_hs = json.load(f)
    except:
      pass

  str_id = str(map_id)
  if str_id not in all_hs or not isinstance(all_hs[str_id], dict):
    all_hs[str_id] = {}

  current_diff_hs = all_hs[str_id].get(difficulty, {"wave": 0})

  if wave > current_diff_hs.get("wave", 0):
    data = {"wave": wave}
    all_hs[str_id][difficulty] = data
    try:
      with open(HIGHSCORE_FILE, "w") as f:
        json.dump(all_hs, f)
    except:
      pass
    return data
  return current_diff_hs


# --- KARTEN / WEGE DEFINITIONEN ---
MAPS = {
    1: {
        "name": "Die Grüne Ebene",
        "waypoints": [(1, 1), (8, 1), (8, 7), (2, 7), (2, 12), (8, 12)],
    },
    2: {
        "name": "Der Schlangenpfad",
        "waypoints": [(1, 2), (8, 2), (8, 6), (1, 6), (1, 11), (8, 11)],
    },
    3: {
        "name": "Nether Schlucht",
        "waypoints": [(1, 1), (8, 1), (8, 12), (1, 12)],
    },
    4: {
        "name": "Das Labyrinth",
        "waypoints": [
            (1, 1),
            (8, 1),
            (8, 5),
            (2, 5),
            (2, 9),
            (8, 9),
            (8, 13),
        ],
    },
    5: {
        "name": "Zickzack-Hölle",
        "waypoints": [
            (1, 6),
            (3, 1),
            (6, 12),
            (8, 3),
            (9, 10),
        ],
    },
    6: {
        "name": "Die End-Insel",
        "waypoints": [
            (5, 1),
            (5, 13),
            (1, 13),
            (1, 7),
            (8, 7),
            (8, 1),
        ],
    },
}

selected_map_id = 1

# Positionen für das Menü (Quadratische Vorschau-Buttons, weiter unten platziert)
map_buttons = {}
start_x, start_y = 90, 180
box_w, box_h = 110, 110
for i in range(1, 7):
  col = (i - 1) % 2
  row = (i - 1) // 2
  rx = start_x + col * (box_w + 14)
  ry = start_y + row * (box_h + 8)
  map_buttons[i] = pygame.Rect(rx, ry, box_w, box_h)

menu_diff_buttons = {
    "easy": pygame.Rect(24, 560, 115, 30),
    "medium": pygame.Rect(149, 560, 115, 30),
    "hard": pygame.Rect(274, 560, 115, 30),
}
play_button_rect = pygame.Rect(107, 600, 200, 40)


# --- ASSET-MANAGER ---
class AssetManager:

  def __init__(self):
    self.sheets = {}
    self.tower_images = {}
    self.map_thumbs = {}
    self.bg_home = None
    self.bg_tile = None
    self.bg_path = None
    self.bg_portal = None
    self.bg_castle = None
    self.load_assets()

  def load_assets(self):
    assets_dir = resource_path("assets")
    if not os.path.exists(assets_dir):
      print(f"[WARNUNG] Der Ordner '{assets_dir}' wurde nicht gefunden!")

    # 1. Menü-Hintergrund (home.png)
    h_path = os.path.join(assets_dir, "home.png")
    if os.path.exists(h_path):
      try:
        self.bg_home = pygame.image.load(h_path).convert()
        print("[ERFOLG] home.png geladen")
      except Exception as e:
        print(f"[FEHLER] home.png: {e}")

    # 2. Tile-Hintergrund (tile1.png)
    t_path = os.path.join(assets_dir, "tile1.png")
    if os.path.exists(t_path):
      try:
        self.bg_tile = pygame.image.load(t_path).convert()
        print("[ERFOLG] tile1.png geladen")
      except Exception as e:
        print(f"[FEHLER] tile1.png: {e}")

    # 3. Pfad-Textur (dirt_path.png)
    dp_path = os.path.join(assets_dir, "dirt_path.png")
    if os.path.exists(dp_path):
      try:
        self.bg_path = pygame.image.load(dp_path).convert_alpha()
        print("[ERFOLG] dirt_path.png geladen")
      except Exception as e:
        print(f"[FEHLER] dirt_path.png: {e}")

    # 4. Portal & Castle für Weg-Anfang/-Ende
    p_path = os.path.join(assets_dir, "portal.png")
    if os.path.exists(p_path):
      try:
        self.bg_portal = pygame.image.load(p_path).convert_alpha()
        print("[ERFOLG] portal.png geladen")
      except Exception as e:
        print(f"[FEHLER] portal.png: {e}")

    c_path = os.path.join(assets_dir, "castle.png")
    if os.path.exists(c_path):
      try:
        self.bg_castle = pygame.image.load(c_path).convert_alpha()
        print("[ERFOLG] castle.png geladen")
      except Exception as e:
        print(f"[FEHLER] castle.png: {e}")

    # 5. Karten-Vorschauen programmatisch mit Innenrand zeichnen, damit nichts verschluckt wird
    for m_id, rect in map_buttons.items():
      thumb_w, thumb_h = rect.width - 16, rect.height - 24
      thumb_surf = pygame.Surface((thumb_w, thumb_h))
      thumb_surf.fill(BLACK)

      waypoints = MAPS[m_id]["waypoints"]
      scaled_points = []
      for gx, gy in waypoints:
        px = int(4 + (gx / max(1, COLS - 1)) * (thumb_w - 16))
        py = int(4 + (gy / max(1, ROWS - 1)) * (thumb_h - 16))
        scaled_points.append((px, py))

      if len(scaled_points) > 1:
        pygame.draw.lines(thumb_surf, WHITE, False, scaled_points, 2)

      self.map_thumbs[m_id] = thumb_surf
      print(f"[ERFOLG] Karten-Vorschau gezeichnet: map{m_id}")

    # Gegner Sprite-Sheets
    enemy_files = {
        "zombie": "zombie.png",
        "creeper": "creeper.png",
        "spider": "spider.png",
        "iron_golem": "iron_golem.png",
        "baby_zombie": "baby_zombie.png",
        "gast": "gast.png",
        "piglin": "piglin.png",
        "enderman": "enderman.png",
    }
    for name, filename in enemy_files.items():
      path = os.path.join(assets_dir, filename)
      if os.path.exists(path):
        try:
          sheet_img = pygame.image.load(path).convert_alpha()
          self.sheets[name] = self.parse_sheet(sheet_img)
        except Exception as e:
          print(f"[FEHLER] Konnte {filename} nicht parsen: {e}")

    # Turm-Bilder
    tower_files = {
        "standard": "standard.png",
        "sniper": "sniper.png",
        "rapid": "rapid.png",
    }
    for name, filename in tower_files.items():
      path = os.path.join(assets_dir, filename)
      if os.path.exists(path):
        try:
          img = pygame.image.load(path).convert_alpha()
          self.tower_images[name] = img
        except Exception as e:
          print(f"[FEHLER] Konnte Tower Bild {filename} nicht parsen: {e}")

  def parse_sheet(self, sheet_img):
    sheet_w, sheet_h = sheet_img.get_size()
    cols = 12
    rows = 4
    frame_w = sheet_w // cols
    frame_h = sheet_h // rows
    frames = {"right": [], "left": [], "up": [], "down": []}
    directions = ["right", "left", "up", "down"]

    for r in range(rows):
      dir_name = directions[r]
      for c in range(cols):
        rect = pygame.Rect(c * frame_w, r * frame_h, frame_w, frame_h)
        frame = pygame.Surface((frame_w, frame_h), pygame.SRCALPHA)
        frame.blit(sheet_img, (0, 0), rect)
        frames[dir_name].append(frame)

    return frames


assets = AssetManager()


def load_map_path(map_id):
  waypoints_grid = MAPS[map_id]["waypoints"]
  cells = set()

  for i in range(len(waypoints_grid) - 1):
    x0, y0 = waypoints_grid[i]
    x1, y1 = waypoints_grid[i + 1]

    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy

    cx, cy = x0, y0
    while True:
      cells.add((cx, cy))
      if cx == x1 and cy == y1:
        break
      e2 = 2 * err
      if e2 > -dy:
        err -= dy
        cx += sx
      if e2 < dx:
        err += dx
        cy += sy

  pixels = [
      (gx * GRID_SIZE + GRID_SIZE // 2, gy * GRID_SIZE + GRID_SIZE // 2)
      for gx, gy in waypoints_grid
  ]
  return cells, waypoints_grid, pixels


PATH_CELLS, WAYPOINTS_GRID, path_pixels = load_map_path(selected_map_id)
START_CELL = WAYPOINTS_GRID[0]
END_CELL = WAYPOINTS_GRID[-1]

# --- GEGNER & TURM PARAMETRIERUNG ---
ENEMY_TYPES = {
    "baby_zombie": {
        "speed": 4.2,
        "health": 50,
        "color": (100, 150, 100),
        "reward": 8,
        "size": 14,
        "sprite": "baby_zombie",
    },
    "spider": {
        "speed": 3.6,
        "health": 75,
        "color": (50, 50, 50),
        "reward": 10,
        "size": 16,
        "sprite": "spider",
    },
    "zombie": {
        "speed": 2.2,
        "health": 120,
        "color": (46, 204, 113),
        "reward": 12,
        "size": 18,
        "sprite": "zombie",
    },
    "creeper": {
        "speed": 2.5,
        "health": 100,
        "color": (0, 200, 0),
        "reward": 15,
        "size": 18,
        "sprite": "creeper",
    },
    "piglin": {
        "speed": 2.0,
        "health": 180,
        "color": (210, 105, 30),
        "reward": 18,
        "size": 18,
        "sprite": "piglin",
    },
    "enderman": {
        "speed": 2.8,
        "health": 220,
        "color": (30, 30, 30),
        "reward": 22,
        "size": 20,
        "sprite": "enderman",
    },
    "iron_golem": {
        "speed": 1.2,
        "health": 450,
        "color": (220, 220, 220),
        "reward": 35,
        "size": 22,
        "sprite": "iron_golem",
    },
    "gast": {
        "speed": 1.4,
        "health": 850,
        "color": (240, 240, 240),
        "reward": 75,
        "size": 24,
        "sprite": "gast",
    },
}

TOWER_TYPES = {
    "standard": {
        "name": "Standard",
        "cost": 100,
        "range": 120,
        "cooldown": 25,
        "damage": 35,
        "color": (41, 128, 185),
        "proj_speed": 9.0,
    },
    "sniper": {
        "name": "Scharfschütze",
        "cost": 180,
        "range": 200,
        "cooldown": 65,
        "damage": 135,
        "color": (24, 44, 97),
        "proj_speed": 18.0,
    },
    "rapid": {
        "name": "Schnellfeuer",
        "cost": 230,
        "range": 100,
        "cooldown": 7,
        "damage": 14,
        "color": (26, 188, 156),
        "proj_speed": 12.0,
    },
}


class Enemy:

  def __init__(self, enemy_type, wave_number, difficulty):
    self.type_name = enemy_type
    stats = ENEMY_TYPES[enemy_type]
    self.x, self.y = path_pixels[0]
    self.path_index = 0
    self.speed = stats["speed"]
    self.sprite_key = stats["sprite"]

    diff_scaling = {"easy": 0.30, "medium": 0.45, "hard": 0.65}[difficulty]
    scale_factor = 1.0 + (wave_number - 1) * diff_scaling
    self.max_health = int(stats["health"] * scale_factor)
    self.health = self.max_health
    self.color = stats["color"]
    self.reward = stats["reward"]
    self.size = stats["size"]
    self.anim_frame = 0
    self.direction = "right"

  def update(self, speed_multiplier):
    eff_speed = self.speed * speed_multiplier
    if self.path_index < len(path_pixels) - 1:
      target_x, target_y = path_pixels[self.path_index + 1]
      dx = target_x - self.x
      dy = target_y - self.y
      dist = math.hypot(dx, dy)

      if abs(dx) > abs(dy):
        self.direction = "right" if dx > 0 else "left"
      else:
        self.direction = "down" if dy > 0 else "up"

      if dist < eff_speed:
        self.path_index += 1
      else:
        self.x += (dx / dist) * eff_speed
        self.y += (dy / dist) * eff_speed

      self.anim_frame = (self.anim_frame + 0.2 * speed_multiplier) % 12
      return False
    else:
      return True

  def draw(self):
    drawn_with_sprite = False
    if self.sprite_key in assets.sheets:
      frames = assets.sheets[self.sprite_key][self.direction]
      if frames:
        current_frame = frames[int(self.anim_frame)]
        scaled_frame = pygame.transform.scale(
            current_frame, (self.size * 2, self.size * 2)
        )
        rect = scaled_frame.get_rect(center=(int(self.x), int(self.y)))
        screen.blit(scaled_frame, rect)
        drawn_with_sprite = True

    if not drawn_with_sprite:
      pygame.draw.circle(
          screen, self.color, (int(self.x), int(self.y)), self.size
      )

    bar_width = max(20, self.size * 2)
    bar_height = 3
    fill = max(0, (self.health / self.max_health) * bar_width)
    pygame.draw.rect(
        screen,
        (200, 50, 50),
        (
            int(self.x) - bar_width / 2,
            int(self.y) - self.size - 7,
            bar_width,
            bar_height,
        ),
    )
    pygame.draw.rect(
        screen,
        (46, 204, 113),
        (
            int(self.x) - bar_width / 2,
            int(self.y) - self.size - 7,
            fill,
            bar_height,
        ),
    )


class Projectile:

  def __init__(self, x, y, target_enemy, tower_type, damage):
    self.x = x
    self.y = y
    self.target = target_enemy
    self.tower_type = tower_type
    self.damage = damage
    self.speed = TOWER_TYPES[tower_type]["proj_speed"]
    self.alive = True

  def update(self, speed_multiplier):
    if not self.target or self.target.health <= 0:
      self.alive = False
      return

    dx = self.target.x - self.x
    dy = self.target.y - self.y
    dist = math.hypot(dx, dy)
    move_dist = self.speed * speed_multiplier

    if dist <= move_dist:
      self.target.health -= self.damage
      self.alive = False
    else:
      self.x += (dx / dist) * move_dist
      self.y += (dy / dist) * move_dist

  def draw(self):
    if self.tower_type == "standard":
      pygame.draw.circle(
          screen, (241, 196, 15), (int(self.x), int(self.y)), 4
      )
    elif self.tower_type == "sniper":
      dx = self.target.x - self.x
      dy = self.target.y - self.y
      dist = max(1, math.hypot(dx, dy))
      tail_x = self.x - (dx / dist) * 12
      tail_y = self.y - (dy / dist) * 12
      pygame.draw.line(screen, (231, 76, 60), (self.x, self.y), (tail_x, tail_y), 2)
    elif self.tower_type == "rapid":
      pygame.draw.circle(screen, (52, 231, 228), (int(self.x), int(self.y)), 2)


class Tower:

  def __init__(self, grid_x, grid_y, tower_type):
    self.grid_x = grid_x
    self.grid_y = grid_y
    self.x = grid_x * GRID_SIZE + GRID_SIZE // 2
    self.y = grid_y * GRID_SIZE + GRID_SIZE // 2

    stats = TOWER_TYPES[tower_type]
    self.type_key = tower_type
    self.range = stats["range"]
    self.max_cooldown = stats["cooldown"]
    self.cooldown = 0
    self.damage = stats["damage"]
    self.color = stats["color"]

  def update(self, enemies, speed_multiplier, projectiles):
    if self.cooldown > 0:
      self.cooldown -= speed_multiplier

    if self.cooldown <= 0:
      for enemy in enemies:
        dist = math.hypot(enemy.x - self.x, enemy.y - self.y)
        if dist <= self.range:
          projectiles.append(
              Projectile(
                  self.x, self.y, enemy, self.type_key, self.damage
              )
          )
          self.cooldown = self.max_cooldown
          break

  def draw(self):
    drawn_with_image = False
    if self.type_key in assets.tower_images:
      img = assets.tower_images[self.type_key]
      scaled_img = pygame.transform.scale(img, (GRID_SIZE - 4, GRID_SIZE - 4))
      rect = scaled_img.get_rect(center=(self.x, self.y))
      screen.blit(scaled_img, rect)
      drawn_with_image = True

    if not drawn_with_image:
      pygame.draw.rect(
          screen,
          self.color,
          (
              self.grid_x * GRID_SIZE + 2,
              self.grid_y * GRID_SIZE + 2,
              GRID_SIZE - 4,
              GRID_SIZE - 4,
          ),
      )

  def draw_range(self):
    surface = pygame.Surface(
        (self.range * 2, self.range * 2), pygame.SRCALPHA
    )
    pygame.draw.circle(
        surface, (50, 150, 250, 40), (self.range, self.range), self.range
    )
    pygame.draw.circle(
        surface, (50, 150, 250, 200), (self.range, self.range), self.range, 2
    )
    screen.blit(surface, (self.x - self.range, self.y - self.range))


# --- SPIEL-VARIABLEN ---
game_state = "MENU"
selected_difficulty = "medium"

towers = []
enemies = []
projectiles = []
gold = 250
lives = 12
wave = 0
wave_queue = []
spawn_timer = 0
game_over = False

selected_tower_type = None
selected_placed_tower = None
game_speed = 1

menu_buttons = [
    {"type": "standard", "rect": pygame.Rect(15, PLAY_HEIGHT + 35, 120, 48)},
    {"type": "sniper", "rect": pygame.Rect(147, PLAY_HEIGHT + 35, 120, 48)},
    {"type": "rapid", "rect": pygame.Rect(279, PLAY_HEIGHT + 35, 120, 48)},
]

speed_buttons = [
    {"speed": 1, "rect": pygame.Rect(275, 10, 28, 25)},
    {"speed": 2, "rect": pygame.Rect(307, 10, 28, 25)},
    {"speed": 4, "rect": pygame.Rect(339, 10, 28, 25)},
    {"speed": 8, "rect": pygame.Rect(371, 10, 28, 25)},
]


def start_new_game(difficulty):
  global towers, enemies, projectiles, gold, lives, wave, wave_queue, spawn_timer, game_over, selected_tower_type, selected_placed_tower, game_speed
  towers = []
  enemies = []
  projectiles = []
  gold = {"easy": 320, "medium": 230, "hard": 160}[difficulty]
  lives = {"easy": 15, "medium": 10, "hard": 5}[difficulty]
  wave = 0
  wave_queue = []
  spawn_timer = 0
  game_over = False
  selected_tower_type = None
  selected_placed_tower = None
  game_speed = 1
  start_next_wave(difficulty)


def generate_wave(wave_num, difficulty):
  queue = []
  count_multiplier = {"easy": 3.5, "medium": 4.8, "hard": 6.5}[difficulty]
  count = int(6 + wave_num * count_multiplier)

  pool = ["baby_zombie", "zombie"]
  if wave_num >= 2:
    pool.append("creeper")
  if wave_num >= 3:
    pool.extend(["spider", "piglin"])
  if wave_num >= 5:
    pool.append("enderman")
  if wave_num >= 7:
    pool.append("iron_golem")
  if wave_num >= 9:
    pool.append("gast")

  for _ in range(count):
    queue.append(random.choice(pool))

  if wave_num % 3 == 0:
    if wave_num >= 9:
      queue.append("gast")
    elif wave_num >= 6:
      queue.append("iron_golem")
    else:
      queue.append("enderman")

  return queue


def start_next_wave(difficulty):
  global wave, wave_queue, spawn_timer
  wave += 1
  wave_queue = generate_wave(wave, difficulty)
  spawn_timer = 0


# --- ASYNCHRONE HAUPTSCHLEIFE ---
async def main():
  global running, game_state, selected_difficulty, towers, enemies, projectiles
  global gold, lives, wave, wave_queue, spawn_timer, game_over
  global selected_tower_type, selected_placed_tower, game_speed
  global selected_map_id, PATH_CELLS, WAYPOINTS_GRID, path_pixels, START_CELL, END_CELL

  clock = pygame.time.Clock()

  running = True
  while running:
    screen.fill(WHITE)
    mx, my = pygame.mouse.get_pos()

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        running = False

      elif event.type == pygame.MOUSEBUTTONDOWN:
        if event.button == 1:
          mx, my = event.pos

          if game_state == "MENU":
            for diff, rect in menu_diff_buttons.items():
              if rect.collidepoint(mx, my):
                selected_difficulty = diff

            for m_id, rect in map_buttons.items():
              if rect.collidepoint(mx, my):
                selected_map_id = m_id
                PATH_CELLS, WAYPOINTS_GRID, path_pixels = load_map_path(
                    selected_map_id
                )
                START_CELL = WAYPOINTS_GRID[0]
                END_CELL = WAYPOINTS_GRID[-1]

            if play_button_rect.collidepoint(mx, my):
              start_new_game(selected_difficulty)
              game_state = "PLAYING"

          elif game_state == "PLAYING":
            clicked_speed = False
            for sb in speed_buttons:
              if sb["rect"].collidepoint(mx, my):
                game_speed = sb["speed"]
                clicked_speed = True
                break

            if not clicked_speed:
              if game_over:
                back_rect = pygame.Rect(
                    WIDTH // 2 - 100, PLAY_HEIGHT // 2 - 20, 200, 40
                )
                if back_rect.collidepoint(mx, my):
                  game_state = "MENU"
                  game_over = False
              else:
                if my >= PLAY_HEIGHT:
                  clicked_button = False
                  for b in menu_buttons:
                    if b["rect"].collidepoint(mx, my):
                      clicked_button = True
                      if selected_tower_type == b["type"]:
                        selected_tower_type = None
                      else:
                        selected_tower_type = b["type"]
                        selected_placed_tower = None
                      break
                  if not clicked_button:
                    selected_tower_type = None
                else:
                  gx = mx // GRID_SIZE
                  gy = my // GRID_SIZE
                  clicked_tower = next(
                      (t for t in towers if t.grid_x == gx and t.grid_y == gy),
                      None,
                  )

                  if selected_tower_type is not None:
                    cost = TOWER_TYPES[selected_tower_type]["cost"]
                    if (
                        clicked_tower is None
                        and (gx, gy) not in PATH_CELLS
                        and gold >= cost
                    ):
                      towers.append(Tower(gx, gy, selected_tower_type))
                      gold -= cost
                  else:
                    selected_placed_tower = clicked_tower

    if game_state == "PLAYING" and not game_over:
      if wave_queue:
        spawn_timer += game_speed
        if spawn_timer >= 30:
          next_enemy = wave_queue.pop(0)
          enemies.append(Enemy(next_enemy, wave, selected_difficulty))
          spawn_timer = 0
      elif len(enemies) == 0 and len(projectiles) == 0:
        start_next_wave(selected_difficulty)

      for enemy in enemies[:]:
        reached_end = enemy.update(game_speed)
        if reached_end:
          enemies.remove(enemy)
          lives -= 1
          if lives <= 0:
            game_over = True
            save_highscore(selected_map_id, selected_difficulty, wave)
        elif enemy.health <= 0:
          gold += enemy.reward
          enemies.remove(enemy)

      for tower in towers:
        tower.update(enemies, game_speed, projectiles)

      for proj in projectiles[:]:
        proj.update(game_speed)
        if not proj.alive:
          projectiles.remove(proj)

    if game_state == "PLAYING":
      # 1. Tile-Hintergrund zeichnen
      if assets.bg_tile:
        tw, th = assets.bg_tile.get_size()
        for ty in range(0, PLAY_HEIGHT, th):
          for tx in range(0, WIDTH, tw):
            screen.blit(assets.bg_tile, (tx, ty))
      else:
        screen.fill(WHITE)
        for x in range(0, WIDTH, GRID_SIZE):
          pygame.draw.line(screen, (240, 240, 240), (x, 0), (x, PLAY_HEIGHT), 1)
        for y in range(0, PLAY_HEIGHT, GRID_SIZE):
          pygame.draw.line(screen, (240, 240, 240), (0, y), (WIDTH, y), 1)

      # 2. Weg-Zellen
      for gx, gy in PATH_CELLS:
        if (gx, gy) == START_CELL and assets.bg_portal:
          portal_img = pygame.transform.scale(
              assets.bg_portal, (GRID_SIZE, GRID_SIZE)
          )
          screen.blit(portal_img, (gx * GRID_SIZE, gy * GRID_SIZE))
        elif (gx, gy) == END_CELL and assets.bg_castle:
          castle_img = pygame.transform.scale(
              assets.bg_castle, (GRID_SIZE, GRID_SIZE)
          )
          screen.blit(castle_img, (gx * GRID_SIZE, gy * GRID_SIZE))
        else:
          if assets.bg_path:
            path_img = pygame.transform.scale(
                assets.bg_path, (GRID_SIZE, GRID_SIZE)
            )
            screen.blit(path_img, (gx * GRID_SIZE, gy * GRID_SIZE))
          else:
            pygame.draw.rect(
                screen,
                PATH_COLOR,
                (gx * GRID_SIZE, gy * GRID_SIZE, GRID_SIZE, GRID_SIZE),
            )

      # 3. Türme
      for tower in towers:
        tower.draw()

      if selected_placed_tower and selected_tower_type is None:
        selected_placed_tower.draw_range()

      # 4. Projektile & Gegner
      for proj in projectiles:
        proj.draw()

      for enemy in enemies:
        enemy.draw()

      # 5. Turm-Vorschau am Cursor
      if selected_tower_type and my < PLAY_HEIGHT:
        gx = mx // GRID_SIZE
        gy = my // GRID_SIZE
        cx = gx * GRID_SIZE + GRID_SIZE // 2
        cy = gy * GRID_SIZE + GRID_SIZE // 2
        stats = TOWER_TYPES[selected_tower_type]

        on_path = (gx, gy) in PATH_CELLS
        preview_color = (231, 76, 60) if on_path else (50, 150, 250)

        preview_surface = pygame.Surface(
            (stats["range"] * 2, stats["range"] * 2), pygame.SRCALPHA
        )
        pygame.draw.circle(
            preview_surface,
            (*preview_color[:3], 40),
            (stats["range"], stats["range"]),
            stats["range"],
        )
        pygame.draw.circle(
            preview_surface,
            (*preview_color[:3], 200),
            (stats["range"], stats["range"]),
            stats["range"],
            1,
        )
        screen.blit(preview_surface, (cx - stats["range"], cy - stats["range"]))

        if selected_tower_type in assets.tower_images:
          t_img = assets.tower_images[selected_tower_type]
          scaled_t = pygame.transform.scale(
              t_img, (GRID_SIZE - 4, GRID_SIZE - 4)
          )
          t_rect = scaled_t.get_rect(center=(cx, cy))
          screen.blit(scaled_t, t_rect)
        else:
          pygame.draw.rect(
              screen,
              stats["color"],
              (
                  gx * GRID_SIZE + 2,
                  gy * GRID_SIZE + 2,
                  GRID_SIZE - 4,
                  GRID_SIZE - 4,
              ),
              2,
          )

      # 6. UI Panel Oben (Statistiken & Speed)
      stats_text = font.render(f"G:{gold} L:{lives} W:{wave}", True, BLACK)
      screen.blit(stats_text, (10, 10))

      for sb in speed_buttons:
        is_curr = game_speed == sb["speed"]
        btn_c = YELLOW if is_curr else LIGHT_GRAY
        pygame.draw.rect(screen, btn_c, sb["rect"], border_radius=4)
        pygame.draw.rect(screen, DARK_GRAY, sb["rect"], width=1, border_radius=4)
        lbl = font_small.render(f"x{sb['speed']}", True, BLACK)
        screen.blit(lbl, (sb["rect"].x + 5, sb["rect"].y + 5))

      # 7. UI Panel Unten (genau 1/4 der Höhe = 184px)
      pygame.draw.rect(screen, PANEL_BG, (0, PLAY_HEIGHT, WIDTH, HEIGHT - PLAY_HEIGHT))

      # A) Auswahl-Sektion
      info_title = font.render("Auswahl:", True, WHITE)
      screen.blit(info_title, (15, PLAY_HEIGHT + 8))

      active_type_key = selected_tower_type or (
          selected_placed_tower.type_key if selected_placed_tower else None
      )
      if active_type_key:
        status_str = "Bauen" if selected_tower_type else "Platziert"
        info_name = font.render(
            f"{TOWER_TYPES[active_type_key]['name']} ({status_str})", True, YELLOW
        )
        screen.blit(info_name, (95, PLAY_HEIGHT + 8))
      else:
        info_none = font_small.render("Kein Turm gewählt", True, GRAY)
        screen.blit(info_none, (95, PLAY_HEIGHT + 10))

      # B) Turm-Buttons Sektion
      for b in menu_buttons:
        t_data = TOWER_TYPES[b["type"]]
        is_selected = selected_tower_type == b["type"]
        btn_color = YELLOW if is_selected else LIGHT_GRAY

        pygame.draw.rect(screen, btn_color, b["rect"], border_radius=6)

        if b["type"] in assets.tower_images:
          t_img = assets.tower_images[b["type"]]
          scaled_icon = pygame.transform.scale(t_img, (30, 30))
          screen.blit(scaled_icon, (b["rect"].x + 6, b["rect"].y + 9))
        else:
          pygame.draw.rect(
              screen,
              t_data["color"],
              (b["rect"].x + 6, b["rect"].y + 9, 30, 30),
              border_radius=4,
          )

        b_name = font_small.render(t_data["name"], True, BLACK)
        b_cost = font_small.render(f"{t_data['cost']}G", True, DARK_GRAY)
        screen.blit(b_name, (b["rect"].x + 40, b["rect"].y + 8))
        screen.blit(b_cost, (b["rect"].x + 40, b["rect"].y + 26))

      # C) Charakteristiken Sektion
      char_title = font.render("Charakteristiken:", True, WHITE)
      screen.blit(char_title, (15, PLAY_HEIGHT + 90))

      if active_type_key:
        t_info = TOWER_TYPES[active_type_key]
        attacks_per_sec = round(60 / t_info["cooldown"], 1)

        txt_dmg = font_small.render(f"Schaden: {t_info['damage']}", True, WHITE)
        txt_rng = font_small.render(f"Reichweite: {t_info['range']}", True, WHITE)
        txt_spd = font_small.render(
            f"Schussrate: {attacks_per_sec}/s", True, WHITE
        )

        screen.blit(txt_dmg, (15, PLAY_HEIGHT + 115))
        screen.blit(txt_rng, (150, PLAY_HEIGHT + 115))
        screen.blit(txt_spd, (275, PLAY_HEIGHT + 115))
      else:
        txt_empty = font_small.render("Turm wählen für Details", True, GRAY)
        screen.blit(txt_empty, (15, PLAY_HEIGHT + 115))

      if game_over:
        go_bg = pygame.Surface((WIDTH, PLAY_HEIGHT))
        go_bg.set_alpha(200)
        go_bg.fill((0, 0, 0))
        screen.blit(go_bg, (0, 0))
        go_text = font_large.render("GAME OVER", True, (231, 76, 60))
        res_text = font.render(f"Du hast Welle {wave} erreicht!", True, WHITE)

        screen.blit(go_text, (WIDTH // 2 - 85, PLAY_HEIGHT // 2 - 40))
        screen.blit(res_text, (WIDTH // 2 - 95, PLAY_HEIGHT // 2 + 5))

        back_rect = pygame.Rect(WIDTH // 2 - 100, PLAY_HEIGHT // 2 + 40, 200, 40)
        pygame.draw.rect(screen, YELLOW, back_rect, border_radius=6)
        back_txt = font.render("Zurück zum Menü", True, BLACK)
        screen.blit(back_txt, (back_rect.x + 25, back_rect.y + 10))

    elif game_state == "MENU":
      if assets.bg_home:
        scaled_home = pygame.transform.scale(assets.bg_home, (WIDTH, HEIGHT))
        screen.blit(scaled_home, (0, 0))
      else:
        screen.fill(PANEL_BG)

      # Highscore anzeigen
      hs = load_highscore(selected_map_id, selected_difficulty)
      map_name = MAPS[selected_map_id]["name"]
      hs_text_str = (
          f"Highscore [{map_name} - {selected_difficulty.capitalize()}]: Welle"
          f" {hs['wave']}"
      )
      hs_surf = font_small.render(hs_text_str, True, YELLOW)

      hs_padding = 8
      hs_box_width = hs_surf.get_width() + hs_padding * 2
      hs_box_height = hs_surf.get_height() + hs_padding * 2
      hs_box_x = WIDTH // 2 - hs_box_width // 2
      hs_box_y = 650

      hs_surface_bg = pygame.Surface(
          (hs_box_width, hs_box_height), pygame.SRCALPHA
      )
      hs_surface_bg.fill((30, 30, 30, 200))
      screen.blit(hs_surface_bg, (hs_box_x, hs_box_y))
      screen.blit(
          hs_surf, (hs_box_x + hs_padding, hs_box_y + hs_padding)
      )

      # Quadratische Karten-Vorschau Boxen mit kleinerer Zeichnung
      for m_id, rect in map_buttons.items():
        is_sel = selected_map_id == m_id
        border_c = YELLOW if is_sel else DARK_GRAY

        box_surface = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        box_surface.fill((40, 44, 52, 220))
        screen.blit(box_surface, (rect.x, rect.y))

        if m_id in assets.map_thumbs:
          thumb = assets.map_thumbs[m_id]
          scaled_thumb = pygame.transform.scale(
              thumb, (rect.width - 16, rect.height - 24)
          )
          screen.blit(scaled_thumb, (rect.x + 8, rect.y + 8))

        pygame.draw.rect(screen, border_c, rect, width=2, border_radius=6)

        m_data = MAPS[m_id]
        lbl = font_small.render(m_data["name"], True, WHITE)
        screen.blit(
            lbl,
            (
                rect.x + (rect.width - lbl.get_width()) // 2,
                rect.y + rect.height - 20,
            ),
        )

      # Schwierigkeitsgrad-Buttons
      for diff, rect in menu_diff_buttons.items():
        is_sel = selected_difficulty == diff
        btn_c = YELLOW if is_sel else LIGHT_GRAY
        pygame.draw.rect(screen, btn_c, rect, border_radius=6)
        txt = font_small.render(diff.capitalize(), True, BLACK)
        screen.blit(
            txt,
            (
                rect.x + (rect.width - txt.get_width()) // 2,
                rect.y + 6,
            ),
        )

      # Play-Button
      pygame.draw.rect(screen, (46, 204, 113), play_button_rect, border_radius=8)
      play_txt = font_large.render("PLAY", True, WHITE)
      screen.blit(
          play_txt,
          (
              play_button_rect.x
              + (play_button_rect.width - play_txt.get_width()) // 2,
              play_button_rect.y + 5,
          ),
      )

    pygame.display.flip()
    clock.tick(60)
    await asyncio.sleep(0)

  pygame.quit()
  sys.exit()


asyncio.run(main())